<?php

namespace App\Http\Controllers\Warga;


use App\Http\Controllers\Controller;
use App\Models\Setoran;

class DashboardController extends Controller
{
    public function index()
    {
        $user = auth()->user();

        $riwayatTerbaru = Setoran::where('user_id', $user->id)
            ->latest()
            ->take(5)
            ->get();

        $stats = [
            'total_setoran' => Setoran::where('user_id', $user->id)->count(),
            'menunggu_verifikasi' => Setoran::where('user_id', $user->id)
                ->where('status', 'pending')->count(),
        ];

        return view('warga.dashboard.main', compact('user', 'riwayatTerbaru', 'stats'));
    }
}
