<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Mitra extends Model
{
    use HasFactory;
    protected $table = 'mitra';
    protected $fillable = ['nama', 'alamat', 'kontak', 'aktif'];

    public function reward()
    {
        return $this->hasMany(Reward::class);
    }
}
