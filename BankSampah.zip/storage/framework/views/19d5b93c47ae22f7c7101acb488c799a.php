<footer class="admin-footer">
	<div class="container-fluid px-3 px-lg-4">
		<span>Copyright 2026 Bank Sampah Digital. <br> Developed by <a target="_blank" class="fw-bold text-success"
				href="https://github.com/edokurniawannnn">Edo Kurniawan</a></span>
	</div>
</footer><?php /**PATH C:\laragon\www\edo-kuliah\eas-bank-sampah\resources\views/layouts/components/footer.blade.php ENDPATH**/ ?>