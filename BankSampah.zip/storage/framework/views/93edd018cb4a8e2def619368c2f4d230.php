<!doctype html>
<html lang="id">

<head>
	<meta charset="UTF-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<meta name="description" content="Halaman Pendaftaran Warga Bank Sampah" />
	<title>Daftar Akun | Bank Sampah Digital</title>

	<link rel="stylesheet" href="<?php echo e(asset('adminhmd/assets/css/bootstrap.min.css')); ?>" />
	<link rel="stylesheet" href="<?php echo e(asset('adminhmd/assets/vendors/bootstrap-icons/bootstrap-icons.css')); ?>" />
	<link rel="stylesheet" href="<?php echo e(asset('adminhmd/assets/css/style.css')); ?>" />
</head>

<body class="auth-body">
	<button class="icon-button theme-toggle auth-theme-toggle" type="button" data-theme-toggle
		aria-label="Switch color theme" title="Switch color theme">
		<i class="bi bi-moon-stars" data-theme-icon aria-hidden="true"></i>
	</button>

	<main class="auth-page">
		<section class="auth-card">
			<a class="auth-brand text-decoration-none" href="<?php echo e(url('/')); ?>">
				<span class="brand-icon"><i class="bi bi-recycle" aria-hidden="true"></i></span>
				<span>
					<strong>Bank Sampah Digital</strong>
					<small>Buat akun nasabah / warga baru.</small>
				</span>
			</a>

			<form method="POST" action="<?php echo e(route('register')); ?>" class="needs-validation" novalidate>
				<?php echo csrf_field(); ?>

				<div class="mb-4">
					<p class="eyebrow mb-1">Akses Terlindungi</p>
					<h1 class="h3 mb-1">Daftar Akun</h1>
					<p class="text-muted mb-0">Lengkapi data diri untuk mulai menabung sampah.</p>
				</div>

				<div class="mb-3">
					<label class="form-label fw-semibold" for="name">Nama Lengkap <span
							class="text-danger">*</span></label>
					<input class="form-control <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nama" name="nama" type="text"
						value="<?php echo e(old('name')); ?>" placeholder="Contoh: Budi Santoso" required autofocus />

					<?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
					<div class="invalid-feedback"><?php echo e($message); ?></div>
					<?php else: ?>
					<div class="invalid-feedback">Nama lengkap wajib diisi.</div>
					<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				</div>

				<div class="mb-3">
					<label class="form-label fw-semibold" for="email">Alamat Email <span
							class="text-danger">*</span></label>
					<input class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="email" name="email"
						type="email" value="<?php echo e(old('email')); ?>" placeholder="contoh@email.com" required />

					<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
					<div class="invalid-feedback"><?php echo e($message); ?></div>
					<?php else: ?>
					<div class="invalid-feedback">Masukkan alamat email yang valid.</div>
					<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				</div>

				<div class="mb-3">
					<label class="form-label fw-semibold" for="password">Password <span
							class="text-danger">*</span></label>
					<input class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="password" name="password"
						type="password" minlength="8" placeholder="Minimal 8 karakter" required />

					<?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
					<div class="invalid-feedback"><?php echo e($message); ?></div>
					<?php else: ?>
					<div class="invalid-feedback">Password wajib diisi (minimal 8 karakter).</div>
					<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				</div>

				<div class="mb-3">
					<label class="form-label fw-semibold" for="password_confirmation">Konfirmasi Password <span
							class="text-danger">*</span></label>
					<input class="form-control" id="password_confirmation" name="password_confirmation" type="password"
						minlength="8" placeholder="Ketik ulang password" required />
					<div class="invalid-feedback">Konfirmasi password wajib diisi.</div>
				</div>

				<div class="form-check mb-4">
					<input class="form-check-input" type="checkbox" id="terms" name="terms" required />
					<label class="form-check-label text-muted" for="terms">
						Saya setuju dengan <a href="#" class="text-decoration-none">syarat dan ketentuan</a> yang
						berlaku.
					</label>
					<div class="invalid-feedback">Anda harus menyetujui syarat & ketentuan sebelum melanjutkan.</div>
				</div>

				<button class="btn btn-primary w-100 fw-semibold" type="submit">
					<i class="bi bi-person-plus me-1" aria-hidden="true"></i> Buat Akun Warga
				</button>
			</form>

			<div class="auth-footer mt-4 text-center">
				Sudah punya akun? <a href="<?php echo e(route('login')); ?>" class="text-decoration-none fw-semibold">Masuk di
					sini</a>
			</div>
		</section>
	</main>

	<script src="<?php echo e(asset('adminhmd/assets/js/bootstrap.bundle.min.js')); ?>"></script>
	<script src="<?php echo e(asset('adminhmd/assets/js/main.js')); ?>"></script>
	<script>
		(() => {
            'use strict'
            const forms = document.querySelectorAll('.needs-validation')
            Array.from(forms).forEach(form => {
                form.addEventListener('submit', event => {
                    if (!form.checkValidity()) {
                        event.preventDefault()
                        event.stopPropagation()
                    }
                    form.classList.add('was-validated')
                }, false)
            })
        })()
	</script>
</body>

</html><?php /**PATH C:\laragon\www\edo-kuliah\eas-bank-sampah\resources\views/auth/register.blade.php ENDPATH**/ ?>