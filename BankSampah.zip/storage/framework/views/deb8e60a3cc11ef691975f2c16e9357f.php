<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="adminHMD professional admin dashboard template">
	<title>Dashboard | Bank Sampah</title>

	<link rel="stylesheet" href="<?php echo e(asset('adminhmd/assets/css/bootstrap.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('adminhmd/assets/vendors/bootstrap-icons/bootstrap-icons.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('adminhmd/assets/css/style.css')); ?>">

	<?php echo $__env->yieldContent('css'); ?>
</head>

<body>
	<div class="admin-shell">
		<?php echo $__env->make('layouts.components.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

		<div class="admin-main">
			<?php echo $__env->make('layouts.components.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>


			<?php echo $__env->yieldContent('content'); ?>


			<?php echo $__env->make('layouts.components.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
		</div>
	</div>

	<?php echo $__env->yieldContent('js'); ?>
	<script src="<?php echo e(asset('adminhmd/assets/js/bootstrap.bundle.min.js')); ?>"></script>
	<script src="<?php echo e(asset('adminhmd/assets/js/main.js')); ?>"></script>
</body>

</html><?php /**PATH C:\laragon\www\edo-kuliah\eas-bank-sampah\resources\views/layouts/app.blade.php ENDPATH**/ ?>